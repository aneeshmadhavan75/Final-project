package com.automation.pages.Interfaces;

public interface SingleProductPage {

    void addToCart();
    void addToCartModal();
    void goToCart();


}
