package com.automation.Pages;

public class SingleProductPage extends BasePage{
}
