package com.automation.pages.Interfaces;

public interface CustomerCarePage {

    void customerCarePage();

    void topicAndIssueSelection(String topic);

    boolean verifyGetAssistanceMsg();

}
