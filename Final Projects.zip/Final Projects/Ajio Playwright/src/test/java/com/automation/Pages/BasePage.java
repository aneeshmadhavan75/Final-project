package com.automation.Pages;

public class BasePage {
}
